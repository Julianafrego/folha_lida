"use client";

import { useEffect, useState } from "react";
import { AppTemplate } from "@/components/templates/AppTemplate";
import { Button } from "@/components/atoms/Button";
import { BookForm } from "@/components/organisms/BookForm";
import { BookList } from "@/components/organisms/BookList";
import { useBooksStore } from "@/store/book.store";

export default function CrudPage() {
  const loadBooks = useBooksStore((state) => state.loadBooks);
  const [isFormOpen, setIsFormOpen] = useState(false);

  useEffect(() => {
    loadBooks();
  }, [loadBooks]);

  return (
    <>
      <AppTemplate>
        <div className="space-y-8">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h2 className="text-xl font-semibold text-zinc-900">
                Biblioteca
              </h2>
              <p className="mt-1 text-sm text-zinc-500">
                Registre sua experiência de leitura.
              </p>
            </div>

            <Button
              type="button"
              variant="primary"
              onClick={() => setIsFormOpen(true)}
            >
              Cadastrar livro
            </Button>
          </div>

          <div>
            <h2 className="mb-4 text-xl font-semibold text-zinc-900">
              Lista de livros
            </h2>
            <BookList />
          </div>
        </div>
      </AppTemplate>

      {isFormOpen ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 px-4 py-8">
          <div className="relative max-h-[90vh] w-full max-w-5xl overflow-y-auto rounded-3xl bg-white shadow-2xl">
            <button
              type="button"
              onClick={() => setIsFormOpen(false)}
              className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-zinc-100 text-xl text-zinc-600 transition hover:bg-zinc-200"
              aria-label="Fechar formulário"
            >
              ×
            </button>

            <div className="p-6 md:p-10">
              <div className="mb-8">
                <h2 className="text-3xl font-bold tracking-tight text-zinc-900">
                  Novo registro de livro
                </h2>
                <p className="mt-2 text-zinc-500">
                  Preencha as informações da sua leitura.
                </p>
              </div>

              <BookForm onSuccess={() => setIsFormOpen(false)} />
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}