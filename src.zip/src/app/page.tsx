import Link from "next/link";

export default function Home() {
  return (
    <main className="flex min-h-screen items-center justify-center bg-zinc-50 px-6">
      <section className="w-full max-w-2xl rounded-xl bg-white p-8 shadow">
        <h1 className="text-3xl font-bold text-purple-800">Folha lida</h1>
        <p className="mt-3 text-zinc-600">
          SUa estante virtual para registrar e organizar seus livros lidos. Crie sua conta e comece a organizar sua biblioteca pessoal hoje mesmo!
        </p>

        <div className="mt-6 flex gap-3">
          <Link
            href="/login"
            className="rounded bg-purple-800 px-4 py-2 text-white"
          >
            Entrar
          </Link>

          <Link
            href="/register"
            className="rounded border text-purple-800 hover:bg-purple-100 px-4 py-2"
          >
            Cadastrar
          </Link>
        </div>
      </section>
    </main>
  );
}