"use client";

import { BookCard } from "@/components/molecules/BookCard";
import { useBooksStore } from "@/store/book.store";

export function BookList() {
  const books = useBooksStore((state) => state.books);

  if (books.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-zinc-300 p-8 text-center">
        <p className="text-zinc-500">Nenhum livro cadastrado ainda.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {books.map((book) => (
        <BookCard key={book.id} book={book} />
      ))}
    </div>
  );
}